import sys
sys.setrecursionlimit(20000)
import time
import random
from randomized_quicksort import randomized_quicksort
from deterministic_quicksort import deterministic_quicksort

def generate_array(size, case_type="random"):
    if case_type == "sorted":
        return list(range(size))
    elif case_type == "reversed":
        return list(range(size, 0, -1))
    elif case_type == "repeated":
        return [5] * size
    else:
        return [random.randint(1, size) for _ in range(size)]

def benchmark(func, arr):
    start = time.time()
    func(arr)
    end = time.time()
    return end - start

def main():
    sizes = [1000, 5000, 10000]
    cases = ["random", "sorted", "reversed", "repeated"]

    for size in sizes:
        for case in cases:
            arr = generate_array(size, case)
            r_time = benchmark(randomized_quicksort, arr[:])
            d_time = benchmark(deterministic_quicksort, arr[:])
            print(f"Size: {size}, Case: {case}, RQ: {r_time:.5f}s, DQ: {d_time:.5f}s")

if __name__ == "__main__":
    main()
