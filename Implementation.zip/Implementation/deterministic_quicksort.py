def deterministic_quicksort(arr):
    if len(arr) <= 1:
        return arr

    pivot = arr[0]
    less = []
    equal = []
    greater = []

    for x in arr:
        if x < pivot:
            less.append(x)
        elif x == pivot:
            equal.append(x)
        else:
            greater.append(x)

    return deterministic_quicksort(less) + equal + deterministic_quicksort(greater)
